#include <px4_platform_common/module.h>
#include <px4_platform_common/module_params.h>
#include <px4_platform_common/log.h>
#include <px4_platform_common/px4_work_queue/ScheduledWorkItem.hpp>
#include <px4_platform_common/tasks.h>

#include <lib/perf/perf_counter.h>

#include <drivers/drv_hrt.h>

#include <uORB/Publication.hpp>
#include <uORB/topics/debug_array.h>

#include <math.h>

#include "auv_common.hpp"
#include "auv_model.hpp"
#include "hopf_observer.hpp"
#include "wave_disturbance.hpp"
#include "mpc_optim.hpp"
#include "thruster_allocation.hpp"

/**
 * @file auv_hopf_main.cpp
 *
 * @brief AUV Hopf + Tube-MPC 主模块
 *
 * 当前版本定位：
 * 1. 先把学术代码主链在 PX4 模块内部完整跑通
 * 2. 使用内部状态 x / z 做闭环仿真
 * 3. 后续再根据需要接入真实 PX4 topic
 *
 * 主要数据流：
 *   d_true      = wave_disturbance.step(x, t)
 *   d_hat       = hopf_observer.update(x, tau_prev, dt)
 *   tau_nom     = mpc_optim.solve(z, xref_hor, d_hat)
 *   tau_applied = thruster_allocation.compute(x, z, d_hat, tau_nom)
 *   x_next      = model.step(x, tau_applied, d_true, dt)
 *   z_next      = model.step(z, tau_nom, d_hat, dt)
 *
 * 说明：
 * - x 为真实状态（actual state）
 * - z 为名义状态（nominal state）
 * - 二者在 reset 时可相同，但运行中必须独立推进
 * - 这样 ancillary / tube 误差 e = x - z 才有真实控制意义
 */

class AuvHopf :
    public ModuleBase, // 注意这里加了 <AuvHopf> 模板
    public ModuleParams
    
{
public:
    static Descriptor desc;

    AuvHopf();
    ~AuvHopf() override;

    static int trampoline(int argc, char *argv[]);
    static int task_spawn(int argc, char *argv[]);
    static AuvHopf *instantiate(int argc, char *argv[]);
    static int custom_command(int argc, char *argv[]);
    static int print_usage(const char *reason = nullptr);

    bool init();
    int print_status() override;
    void run() override;

private:
    // --------------------------------------------------
    // 核心算法对象
    // --------------------------------------------------
    AuvModel _model;
    HopfObserver _hopf;
    WaveDisturbance _wave;
    MpcOptim _mpc;
    ThrusterAllocation _alloc;
    
    //----------------------------------------------
    // 性能计数器
    //----------------------------------------------
    perf_counter_t _perf_mpc_solve{perf_alloc(PC_ELAPSED, "auv_hopf_mpc")};
    perf_counter_t _perf_total_run{perf_alloc(PC_ELAPSED, "auv_hopf_total")};

    // --------------------------------------------------
    // 状态变量
    // x : 真实状态 actual state
    // z : 名义状态 nominal state
    // --------------------------------------------------
    auv::StateVec _x{};
    auv::StateVec _z{};

    // 当前参考点
    auv::StateVec _xref{};

    // 当前真实扰动 / 学习估计 / 控制量
    auv::InputVec _d_true{};
    auv::InputVec _d_hat{};
    auv::InputVec _tau_nom{};
    auv::InputVec _tau_applied{};
    auv::InputVec _tau_prev{};

    // 调度时间
    hrt_abstime _last_run{0};
    float _sim_time{0.0f};

    // MPC 参考时域缓存
    float _xref_hor[auv::NX * auv::NHOR_MAX]{};
    int _xref_nhor{0};

    // 调试输出
    uORB::Publication<debug_array_s> _debug_pub{ORB_ID(debug_array)};

    // 内部帮助函数
    void reset_states();
    void build_reference(float t);
    void build_reference_horizon();
    void publish_debug(float dt);

    static float sanitize_dt(float dt);
};

// 构造函数
AuvHopf::AuvHopf() :
    ModuleParams(nullptr)
{
    reset_states();
}
// 析构函数
AuvHopf::~AuvHopf()
{
    perf_free(_perf_mpc_solve);
    perf_free(_perf_total_run);
}

float AuvHopf::sanitize_dt(float dt)
{
    if (!PX4_ISFINITE(dt) || dt <= 0.0f) {
        return 0.02f;
    }

    if (dt > 0.2f) {
        return 0.2f;
    }

    return dt;
}

void AuvHopf::reset_states()
{
    _x.zero();
    _z.zero();
    _xref.zero();

    _d_true.zero();
    _d_hat.zero();
    _tau_nom.zero();
    _tau_applied.zero();
    _tau_prev.zero();

    _sim_time = 0.0f;
    _last_run = 0;
    _xref_nhor = 0;

    // -----------------------------
    // 初始真实状态
    // -----------------------------
    _x(0) = 0.0f;   // X
    _x(1) = 0.0f;   // Y
    _x(2) = 0.0f;   // psi
    _x(3) = 0.0f;   // u
    _x(4) = 0.0f;   // v
    _x(5) = 0.0f;   // r

    // -----------------------------
    // 初始名义状态
    //
    // reset 时允许 z(0)=x(0)
    // 但运行后 z 必须独立递推，不能再被 x 覆盖
    // -----------------------------
    _z = _x;

    for (int i = 0; i < auv::NX * auv::NHOR_MAX; ++i) {
        _xref_hor[i] = 0.0f;
    }

    _wave.reset();
    _hopf.reset();
    _mpc.reset();
}

/**
 * @brief 构造当前参考轨迹点
 *
 * 示例使用平面圆轨迹：
 *   Xref = R cos(wt)
 *   Yref = R sin(wt)
 *   psiref = atan2(Ydot, Xdot)
 */
void AuvHopf::build_reference(float t)
{
    const float R = 8.0f;
    const float w = 0.08f;

    const float xr = R * cosf(w * t);
    const float yr = R * sinf(w * t);

    const float xdot_r = -R * w * sinf(w * t);
    const float ydot_r =  R * w * cosf(w * t);

    const float psi_r = atan2f(ydot_r, xdot_r);
    const float u_r = sqrtf(xdot_r * xdot_r + ydot_r * ydot_r);
    const float v_r = 0.0f;
    const float r_r = w;

    _xref.zero();
    _xref(0) = xr;
    _xref(1) = yr;
    _xref(2) = psi_r;
    _xref(3) = u_r;
    _xref(4) = v_r;
    _xref(5) = r_r;
}

/**
 * @brief 构造 MPC 参考时域
 *
 * 按平铺方式组织：
 *   [x0(0..5), x1(0..5), ..., xN(0..5)]
 */
void AuvHopf::build_reference_horizon()
{
    _xref_nhor = (_mpc.horizon_length() > 0) ? _mpc.horizon_length() : 20;
    const float dt = (_mpc.sample_time() > 0.0f) ? _mpc.sample_time() : 0.02f;

    for (int k = 0; k < auv::NHOR_MAX; ++k) {
        for (int i = 0; i < auv::NX; ++i) {
            _xref_hor[k * auv::NX + i] = 0.0f;
        }
    }

    for (int k = 0; k < _xref_nhor && k < auv::NHOR_MAX; ++k) {
        const float tk = _sim_time + static_cast<float>(k) * dt;

        const float R = 8.0f;
        const float w = 0.08f;

        const float xr = R * cosf(w * tk);
        const float yr = R * sinf(w * tk);

        const float xdot_r = -R * w * sinf(w * tk);
        const float ydot_r =  R * w * cosf(w * tk);

        const float psi_r = atan2f(ydot_r, xdot_r);
        const float u_r = sqrtf(xdot_r * xdot_r + ydot_r * ydot_r);
        const float v_r = 0.0f;
        const float r_r = w;

        _xref_hor[k * auv::NX + 0] = xr;
        _xref_hor[k * auv::NX + 1] = yr;
        _xref_hor[k * auv::NX + 2] = psi_r;
        _xref_hor[k * auv::NX + 3] = u_r;
        _xref_hor[k * auv::NX + 4] = v_r;
        _xref_hor[k * auv::NX + 5] = r_r;
    }
}

bool AuvHopf::init()
{
    const auto plant = auv::default_plant_params();
    const auto hopf_cfg = auv::default_hopf_config();
    const auto wave_env = auv::default_wave_env_params();
    const auto wave_model = auv::default_wave_force_model_params();
    const auto tube = auv::default_tube_feedback_params();
    const auto mpc_w = auv::default_mpc_weight_params();
    const auto mpc_b = auv::default_mpc_bounds_params();
    const auto mpc_c = auv::default_mpc_config();

    _model.set_plant_params(plant);

    _hopf.set_plant_params(plant);
    _hopf.set_hopf_config(hopf_cfg);

    _wave.set_wave_env(wave_env);
    _wave.set_model_params(wave_model);

    _alloc.set_plant_params(plant);
    _alloc.set_params(tube);

    _mpc.set_plant_params(plant);
    _mpc.set_weight_params(mpc_w);
    _mpc.set_bounds_params(mpc_b);
    _mpc.set_mpc_config(mpc_c);
    _mpc.initialize(mpc_c.dt, mpc_c.Thor);

    reset_states();

    PX4_INFO("auv_hopf started");
    return true;
}

void AuvHopf::publish_debug(float dt)
{
    debug_array_s dbg{};
    dbg.timestamp = hrt_absolute_time();
    dbg.id = 0;

    dbg.data[0]  = _sim_time;
    dbg.data[1]  = dt;

    dbg.data[2]  = _x(0);
    dbg.data[3]  = _x(1);
    dbg.data[4]  = _x(2);
    dbg.data[5]  = _x(3);
    dbg.data[6]  = _x(4);
    dbg.data[7]  = _x(5);

    dbg.data[8]  = _z(0);
    dbg.data[9]  = _z(1);
    dbg.data[10] = _z(2);
    dbg.data[11] = _z(3);
    dbg.data[12] = _z(4);
    dbg.data[13] = _z(5);

    dbg.data[14] = _xref(0);
    dbg.data[15] = _xref(1);
    dbg.data[16] = _xref(2);
    dbg.data[17] = _xref(3);
    dbg.data[18] = _xref(4);
    dbg.data[19] = _xref(5);

    dbg.data[20] = _d_true(0);
    dbg.data[21] = _d_true(1);
    dbg.data[22] = _d_true(2);

    dbg.data[23] = _d_hat(0);
    dbg.data[24] = _d_hat(1);
    dbg.data[25] = _d_hat(2);

    dbg.data[26] = _tau_nom(0);
    dbg.data[27] = _tau_nom(1);
    dbg.data[28] = _tau_nom(2);

    dbg.data[29] = _tau_applied(0);
    dbg.data[30] = _tau_applied(1);
    dbg.data[31] = _tau_applied(2);

    const auto &hopf_dbg = _hopf.debug();
    dbg.data[32] = hopf_dbg.surge.d_raw;
    dbg.data[33] = hopf_dbg.surge.d_pred_before;
    dbg.data[34] = hopf_dbg.surge.f_error;

    dbg.data[35] = hopf_dbg.sway.d_raw;
    dbg.data[36] = hopf_dbg.sway.d_pred_before;
    dbg.data[37] = hopf_dbg.sway.f_error;

    dbg.data[38] = hopf_dbg.yaw.d_raw;
    dbg.data[39] = hopf_dbg.yaw.d_pred_before;
    dbg.data[40] = hopf_dbg.yaw.f_error;

    const auto &alloc_dbg = _alloc.debug();
    dbg.data[41] = alloc_dbg.tau_fb(0);
    dbg.data[42] = alloc_dbg.tau_fb(1);
    dbg.data[43] = alloc_dbg.tau_fb(2);

    dbg.data[44] = alloc_dbg.tau_ancillary(0);
    dbg.data[45] = alloc_dbg.tau_ancillary(1);
    dbg.data[46] = alloc_dbg.tau_ancillary(2);

    dbg.data[47] = alloc_dbg.tau_raw(0);
    dbg.data[48] = alloc_dbg.tau_raw(1);
    dbg.data[49] = alloc_dbg.tau_raw(2);

    dbg.data[50] = static_cast<float>(_xref_nhor);

    // 可选：把 x-z 误差也打出来，便于验证 nominal 是否独立
    dbg.data[51] = _x(0) - _z(0);
    dbg.data[52] = _x(1) - _z(1);
    dbg.data[53] = _x(2) - _z(2);
    dbg.data[54] = _x(3) - _z(3);
    dbg.data[55] = _x(4) - _z(4);
    dbg.data[56] = _x(5) - _z(5);

    _debug_pub.publish(dbg);
}

void AuvHopf::run()
{
    if (!init()) {
        PX4_ERR("init failed");
        return;
    }

    float dt = (_mpc.sample_time() > 0.0f) ? _mpc.sample_time() : 0.02f;
    dt = sanitize_dt(dt);
    const hrt_abstime dt_us = static_cast<hrt_abstime>(dt * 1e6f);

    //锚定系统绝对时间作为循环起点，避免初始 dt 过大
    hrt_abstime next_run_time = hrt_absolute_time();

    while (!should_exit()) {

        next_run_time += dt_us;
        //---------------------------------
        // --- 算法执行块开始 性能计数器：总运行时间---
        // ---------------------------------
        perf_begin(_perf_total_run);
        _sim_time += dt;
        // --------------------------------------------------
        // 1) 构造当前参考与参考时域
        // --------------------------------------------------
        build_reference(_sim_time);
        build_reference_horizon();

        // --------------------------------------------------
        // 2) 真实外扰
        //
        // 真实扰动只作用在 actual state x 的推进上
        // --------------------------------------------------
        _d_true = _wave.step(_x, _sim_time);

        // --------------------------------------------------
        // 3) Hopf 在线扰动学习
        // 它内部利用状态差分和上一拍实际执行控制，反推原始扰动并学习
        // --------------------------------------------------
        _d_hat = _hopf.update(_x, _tau_prev, dt);

        // --------------------------------------------------
        // 4) 用 nominal state z 设置 MPC 初值和时域参考
        //
        // 这是 nominal 闭环的入口，不能再用 x 代替 z
        // --------------------------------------------------
        _mpc.set_reference_horizon(_z, _xref_hor, _xref_nhor, _d_hat);

        // --------------------------------------------------
        // 5) 求 nominal control
        // --------------------------------------------------
        _tau_nom = _mpc.solve();

        // --------------------------------------------------
        // 6) ancillary / allocation
        //
        // 这里显式依赖 x-z 误差，因此必须保证 z 是独立轨道
        // --------------------------------------------------
        _tau_applied = _alloc.compute(_x, _z, _d_hat, _tau_nom);

        // --------------------------------------------------
        // 7) 真实状态推进：actual state x
        //
        // 真实系统受实际执行控制 tau_applied
        // 与真实扰动 d_true 共同作用
        // --------------------------------------------------
        _x = _model.step(_x, _tau_applied, _d_true, dt);

        // --------------------------------------------------
        // 8) 名义状态推进：nominal state z
        //
        // 关键修正：
        // 不再写 _z = _x
        // 而是由 nominal model 自己递推
        //
        // 这里沿用你当前工程语义：
        // 名义系统在 tau_nom 和 d_hat 下推进
        // --------------------------------------------------
        _z = _model.step(_z, _tau_nom, _d_hat, dt);

        // --------------------------------------------------
        // 9) 更新上一拍实际执行控制
        //
        // 供 HopfObserver 下一次 update() 使用
        // --------------------------------------------------
        _tau_prev = _tau_applied;

        //--------------------------------------------------
        // 性能计数器：MPC 求解时间
        //--------------------------------------------------
        perf_begin(_perf_mpc_solve); // 核心：单独记录 MPC 求解耗时
        _tau_nom = _mpc.solve();
        perf_end(_perf_mpc_solve);

        // --------------------------------------------------
        // 10) 发布调试信息
        // --------------------------------------------------
        publish_debug(dt);
        
        // --------------------------------------------------
        // 算法执行结束，性能计数器：总运行时间
        perf_end(_perf_total_run);

        // --------------------------------------------------
        // 4. 时序控制：计算剩余裕量并让出 CPU
        hrt_abstime now = hrt_absolute_time();
        if (now < next_run_time) {
            // 你那 19ms 的裕量就在这里被精准地让给了系统其他任务
            px4_usleep(next_run_time - now);
        } else {
            // 兜底保护：如果极其偶尔的情况下算超时了，打出警告，防止系统卡死
            PX4_WARN("Deadline Missed! dt overrun.");
            next_run_time = now; // 重置时间锚点
        }
    }
}

int AuvHopf::print_status()
{
    PX4_INFO("running");
    PX4_INFO("t = %.3f", (double)_sim_time);

    PX4_INFO("x = [%.3f %.3f %.3f %.3f %.3f %.3f]",
             (double)_x(0), (double)_x(1), (double)_x(2),
             (double)_x(3), (double)_x(4), (double)_x(5));

    PX4_INFO("z = [%.3f %.3f %.3f %.3f %.3f %.3f]",
             (double)_z(0), (double)_z(1), (double)_z(2),
             (double)_z(3), (double)_z(4), (double)_z(5));

    PX4_INFO("xref = [%.3f %.3f %.3f %.3f %.3f %.3f]",
             (double)_xref(0), (double)_xref(1), (double)_xref(2),
             (double)_xref(3), (double)_xref(4), (double)_xref(5));

    PX4_INFO("x-z = [%.3f %.3f %.3f %.3f %.3f %.3f]",
             (double)(_x(0) - _z(0)),
             (double)(_x(1) - _z(1)),
             (double)(_x(2) - _z(2)),
             (double)(_x(3) - _z(3)),
             (double)(_x(4) - _z(4)),
             (double)(_x(5) - _z(5)));

    PX4_INFO("d_true = [%.3f %.3f %.3f]",
             (double)_d_true(0), (double)_d_true(1), (double)_d_true(2));

    PX4_INFO("d_hat = [%.3f %.3f %.3f]",
             (double)_d_hat(0), (double)_d_hat(1), (double)_d_hat(2));

    PX4_INFO("tau_nom = [%.3f %.3f %.3f]",
             (double)_tau_nom(0), (double)_tau_nom(1), (double)_tau_nom(2));

    PX4_INFO("tau_applied = [%.3f %.3f %.3f]",
             (double)_tau_applied(0), (double)_tau_applied(1), (double)_tau_applied(2));

    PX4_INFO("xref_nhor = %d", _xref_nhor);

    return 0;
}


AuvHopf *AuvHopf::instantiate(int argc, char *argv[])
{
    return new AuvHopf();
}

// ==========================================================
// 线程入口跳板：系统在这里创建实例，并卡入死循环
// ==========================================================
int AuvHopf::trampoline(int argc, char *argv[])
{
    AuvHopf *instance = new AuvHopf();
    if (!instance) {
        PX4_ERR("alloc failed");
        return -1;
    }

    // 将实例注册到系统描述符中
    desc.object.store(instance);

    // 开始执行核心硬实时大循环 (run 内部会自动调用 init)
    instance->run();

    // 只有当收到 stop 命令，退出 while(!should_exit()) 后，才会执行到这里
    delete instance;
    desc.object.store(nullptr);
    desc.task_id = -1;
    return 0;
}

// 替换原来的 task_spawn
int AuvHopf::task_spawn(int argc, char *argv[])
{
    // 向系统申请独立线程，并将程序入口指向 trampoline
    int task_id = px4_task_spawn_cmd("auv_hopf",
                                     SCHED_DEFAULT,
                                     SCHED_PRIORITY_ATTITUDE_CONTROL,
                                     4096,
                                     (px4_main_t)&AuvHopf::trampoline, // 指向跳板函数
                                     (char *const *)argv);

    if (task_id < 0) {
        return -errno; // 启动失败
    }

    // 🚨 把系统分配给你的真实特权线程号存起来
    desc.task_id = task_id; 
    return 0;
}

int AuvHopf::custom_command(int argc, char *argv[])
{
    return print_usage("unknown command");
}

int AuvHopf::print_usage(const char *reason)
{
    if (reason) {
        PX4_WARN("%s", reason);
    }

    PRINT_MODULE_DESCRIPTION(
        R"DESCR_STR(
### Description
AUV Hopf + Tube-MPC composite control module.

Current version runs the academic closed-loop chain internally:
wave disturbance -> Hopf learner -> MPC -> ancillary allocation -> plant update

Key property of this version:
- actual state x and nominal state z are propagated independently
- z is no longer overwritten by x
- tube / ancillary feedback therefore has actual closed-loop meaning
)DESCR_STR");

    PRINT_MODULE_USAGE_NAME("auv_hopf", "template");
    PRINT_MODULE_USAGE_COMMAND("start");
    PRINT_MODULE_USAGE_COMMAND("status");
    PRINT_MODULE_USAGE_COMMAND("stop");
    return 0;
}

ModuleBase::Descriptor AuvHopf::desc{AuvHopf::task_spawn, AuvHopf::custom_command, AuvHopf::print_usage};

extern "C" __EXPORT int auv_hopf_main(int argc, char *argv[])
{
    // 正确的写法：调用 ModuleBase 的 main，并把我们自己的名片 (desc) 传进去！
    return ModuleBase::main(AuvHopf::desc, argc, argv); 
}